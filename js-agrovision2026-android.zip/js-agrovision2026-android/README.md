
# JS Agrovision2026 Android App

AI-powered cotton crop disease detection mobile application.

## Features
- Cotton disease detection UI
- Camera scan interface
- AI dashboard
- Weather intelligence
- Smart recommendations
- Offline-ready structure

## Run

### Install Expo
npm install -g expo-cli

### Install dependencies
npm install

### Start app
npm start

### Build Android APK
eas build -p android

## Team
- Ghulam Jelani (AI & Automation Engineer)
- Mehboob Ahmed (App Developer)
- Minahil Jelani (Data Analyst)
- Eeshal Jelani (Data Analyzer)
- Abu Bakar Siddique (Graphics Designer)
