
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity
} from 'react-native';

export default function App() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>🌿 JS Agrovision2026</Text>
        <Text style={styles.subtitle}>
          AI Powered Smart Agriculture
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>📷 Scan Plant</Text>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Capture Cotton Leaf</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>🦠 Detection Result</Text>
        <Text style={styles.result}>
          Cotton Leaf Curl Virus Detected
        </Text>
        <Text style={styles.confidence}>
          Confidence: 92%
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>💊 Recommendations</Text>
        <Text style={styles.item}>• Spray Imidacloprid</Text>
        <Text style={styles.item}>• Apply Zinc Sulphate</Text>
        <Text style={styles.item}>• Remove infected leaves</Text>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Designed & Built by JS Team
        </Text>

        <Text style={styles.team}>
          Ghulam Jelani (AI & Automation Engineer)
        </Text>

        <Text style={styles.team}>
          Mehboob Ahmed (App Developer)
        </Text>

        <Text style={styles.team}>
          Minahil Jelani (Data Analyst)
        </Text>

        <Text style={styles.team}>
          Eeshal Jelani (Data Analyzer)
        </Text>

        <Text style={styles.team}>
          Abu Bakar Siddique (Graphics Designer)
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eef9f0'
  },
  header: {
    backgroundColor: '#0b7a36',
    padding: 30,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25
  },
  title: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold'
  },
  subtitle: {
    color: '#d9ffe3',
    marginTop: 10,
    fontSize: 16
  },
  card: {
    backgroundColor: '#fff',
    margin: 15,
    padding: 20,
    borderRadius: 20
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0b7a36',
    marginBottom: 15
  },
  button: {
    backgroundColor: '#0b7a36',
    padding: 16,
    borderRadius: 15
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  result: {
    fontSize: 20,
    color: '#d62828',
    fontWeight: 'bold'
  },
  confidence: {
    marginTop: 10,
    fontSize: 18,
    color: '#0b7a36'
  },
  item: {
    fontSize: 17,
    marginBottom: 10
  },
  footer: {
    backgroundColor: '#0b7a36',
    padding: 25,
    marginTop: 20
  },
  footerText: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15
  },
  team: {
    color: '#d9ffe3',
    marginBottom: 8
  }
});
